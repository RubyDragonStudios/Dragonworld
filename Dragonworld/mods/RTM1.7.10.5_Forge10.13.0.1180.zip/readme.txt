﻿***このModで使用している素材***

・音声素材
rtm_dc40r_a.ogg
rtm_dc40r_a-i.ogg
rtm_dc40r_go-a.ogg
rtm_dc40r_i.ogg
rtm_dc40r_i-stop.ogg
rtm_dc40r_stn.ogg
rtm_E231sbb_go-mid.ogg
rtm_E231sbb_mid.ogg
rtm_E231sbb_mid-stop.ogg
rtm_E231sbb_mid-top.ogg
rtm_E231sbb_top.ogg
rtm_E231sbb_top-mid.ogg
rtm_wh_00l.ogg

以上は「Simulation Country GAPAN 月本国」様（http://freett.com/gepponkoku/index.htm）よりお借りしました。

humikiri.ogg : I'sZako 様
よりご提供していただきました。


・テクスチャ
sign_1.png ~ sign_10.png, itemEC.png, itemFC.png : おなべ 様
sign_11.png ~ sign_17.png : マイクラでGO 様
sign_19.png ~ sign_34.png : いずみ 様
よりご提供していただきました。